import config

def calculate_position_size(account_size, risk_per_trade, entry_price, stop_price, current_price):
    """
    Calculates appropriate position size based on risk parameters and leverage
    
    Args:
        account_size: Total account size in USD
        risk_per_trade: Amount willing to risk per trade in USD
        entry_price: Entry price for the trade
        stop_price: Stop loss price
        current_price: Current market price
        
    Returns:
        Dictionary with position size information
    """
    # Use the provided risk amount per trade
    risk_amount = risk_per_trade
    
    # Calculate risk percentage
    risk_percentage = (risk_amount / account_size) * 100
    
    # Calculate stop distance as percentage
    stop_distance_percent = abs(entry_price - stop_price) / entry_price
    
    # Calculate position size considering leverage
    # Formula: Risk amount / (Stop distance × Asset price × Leverage adjustment)
    position_value_without_leverage = risk_amount / stop_distance_percent
    position_value = position_value_without_leverage / config.LEVERAGE
    
    # Calculate units based on position value
    units = position_value / current_price
    
    # Verify if position size is within account limits
    max_position = account_size * config.LEVERAGE
    if position_value > max_position:
        position_value = max_position
        units = position_value / current_price
    
    return {
        'units': units,
        'position_value': position_value,
        'position_value_with_leverage': position_value * config.LEVERAGE,
        'percentage_of_account': (position_value / account_size) * 100,
        'risk_percentage': risk_percentage,
        'max_loss': risk_amount,
        'stop_distance_percent': stop_distance_percent * 100,
        'leverage': config.LEVERAGE,
        'risk_reward_ratio': 2.0  # Default to 2R targets as per Big Char Trades
    }
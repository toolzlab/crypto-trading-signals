import numpy as np
import pandas as pd

def detect_smt(asset1_candles, asset2_candles, lookback=10):
    """
    Detects Smart Money Technique (SMT) divergences between correlated assets.
    
    Args:
        asset1_candles: DataFrame with OHLC data for primary asset
        asset2_candles: DataFrame with OHLC data for correlated asset
        lookback: Number of candles to look back
    
    Returns:
        Dictionary with detected SMT patterns
    """
    smt_patterns = {'bullish': [], 'bearish': []}
    
    if asset1_candles is None or asset2_candles is None:
        return smt_patterns
    
    # Ensure we're comparing the same time periods
    common_dates = sorted(set(asset1_candles.index).intersection(set(asset2_candles.index)))
    if len(common_dates) < lookback + 1:
        return smt_patterns
    
    asset1_candles = asset1_candles.loc[common_dates]
    asset2_candles = asset2_candles.loc[common_dates]
    
    for i in range(lookback, len(asset1_candles)-1):
        # Check for SMT at lows (bullish)
        # If Asset1 makes a lower low but Asset2 makes a higher low
        if (asset1_candles['low'].iloc[i] < asset1_candles['low'].iloc[i-1] and
            asset2_candles['low'].iloc[i] > asset2_candles['low'].iloc[i-1]):
            smt_patterns['bullish'].append({
                'idx': i,
                'timestamp': asset1_candles.index[i],
                'strength': abs(
                    (asset1_candles['low'].iloc[i] / asset1_candles['low'].iloc[i-1]) -
                    (asset2_candles['low'].iloc[i] / asset2_candles['low'].iloc[i-1])
                )
            })
        
        # Check for SMT at highs (bearish)
        # If Asset1 makes a higher high but Asset2 makes a lower high
        if (asset1_candles['high'].iloc[i] > asset1_candles['high'].iloc[i-1] and
            asset2_candles['high'].iloc[i] < asset2_candles['high'].iloc[i-1]):
            smt_patterns['bearish'].append({
                'idx': i,
                'timestamp': asset1_candles.index[i],
                'strength': abs(
                    (asset1_candles['high'].iloc[i] / asset1_candles['high'].iloc[i-1]) -
                    (asset2_candles['high'].iloc[i] / asset2_candles['high'].iloc[i-1])
                )
            })
    
    return smt_patterns
import numpy as np
import pandas as pd
import config

def detect_order_blocks(candles, lookback=50):
    """
    Detects order blocks in candlestick data.
    
    An order block is formed when:
    - In an uptrend: The last down closed candle before a strong move up
    - In a downtrend: The last up closed candle before a strong move down
    
    Args:
        candles: DataFrame with OHLC data
        lookback: Number of candles to look back
        
    Returns:
        List of detected order blocks with their properties
    """
    if candles is None or len(candles) < lookback + 5:
        return []
    
    order_blocks = []
    
    # Calculate average candle body size
    candles['body_size'] = abs(candles['close'] - candles['open'])
    avg_body_size = candles['body_size'].rolling(20).mean()
    
    # Function to check if a candle is an up or down candle
    def is_up_candle(i):
        return candles['close'].iloc[i] > candles['open'].iloc[i]
    
    # Function to check if subsequent move is significant
    def is_significant_move(start, direction, bars=3):
        if direction == 'up':
            move_size = candles['high'].iloc[start:start+bars].max() - candles['low'].iloc[start]
            return move_size > 2 * avg_body_size.iloc[start]
        else:
            move_size = candles['low'].iloc[start] - candles['low'].iloc[start:start+bars].min()
            return move_size > 2 * avg_body_size.iloc[start]
    
    # Scan for potential order blocks
    for i in range(5, len(candles) - 5):
        # Check for bearish order block (last up candle before a down move)
        if is_up_candle(i) and not is_up_candle(i+1) and not is_up_candle(i+2):
            if is_significant_move(i+1, 'down'):
                # Found a potential bearish order block
                order_blocks.append({
                    'type': 'bearish',
                    'index': i,
                    'timestamp': candles.index[i],
                    'top': candles['high'].iloc[i],
                    'bottom': candles['low'].iloc[i],
                    'entry': candles['open'].iloc[i],
                    'status': 'active'
                })
        
        # Check for bullish order block (last down candle before an up move)
        if not is_up_candle(i) and is_up_candle(i+1) and is_up_candle(i+2):
            if is_significant_move(i+1, 'up'):
                # Found a potential bullish order block
                order_blocks.append({
                    'type': 'bullish',
                    'index': i,
                    'timestamp': candles.index[i],
                    'top': candles['high'].iloc[i],
                    'bottom': candles['low'].iloc[i],
                    'entry': candles['open'].iloc[i],
                    'status': 'active'
                })
    
    # Determine which order blocks have been mitigated
    for i, ob in enumerate(order_blocks):
        if ob['type'] == 'bullish':
            # Bullish OB is mitigated if price trades below its low
            for j in range(ob['index'] + 3, len(candles)):
                if candles['low'].iloc[j] < ob['bottom']:
                    order_blocks[i]['status'] = 'mitigated'
                    order_blocks[i]['mitigation_index'] = j
                    order_blocks[i]['mitigation_timestamp'] = candles.index[j]
                    break
        else:
            # Bearish OB is mitigated if price trades above its high
            for j in range(ob['index'] + 3, len(candles)):
                if candles['high'].iloc[j] > ob['top']:
                    order_blocks[i]['status'] = 'mitigated'
                    order_blocks[i]['mitigation_index'] = j
                    order_blocks[i]['mitigation_timestamp'] = candles.index[j]
                    break
    
    return order_blocks

def is_valid_pd_array(ob, candles, current_idx=None):
    """
    Determines if an order block is a valid Premium Discount array for trading
    
    Args:
        ob: Order block dictionary
        candles: DataFrame with OHLC data
        current_idx: Current candle index (defaults to last candle)
        
    Returns:
        Boolean indicating if the order block is a valid PD array
    """
    if current_idx is None:
        current_idx = len(candles) - 1
    
    # Order block must be active (not mitigated)
    if ob['status'] != 'active':
        return False
    
    # Order block should not be too old (within last 100 candles)
    if current_idx - ob['index'] > 100:
        return False
    
    # For bullish OB, current price should be above OB
    if ob['type'] == 'bullish':
        return candles['close'].iloc[current_idx] > ob['top']
    
    # For bearish OB, current price should be below OB
    if ob['type'] == 'bearish':
        return candles['close'].iloc[current_idx] < ob['bottom']
    
    return False

def find_nearest_order_block(candles, direction='bullish'):
    """
    Find the nearest valid order block for the specified direction
    
    Args:
        candles: DataFrame with OHLC data
        direction: 'bullish' or 'bearish'
        
    Returns:
        Dictionary with nearest order block data
    """
    order_blocks = detect_order_blocks(candles)
    
    # Filter order blocks by direction and keep only active ones
    filtered_obs = [ob for ob in order_blocks if ob['type'] == direction and ob['status'] == 'active']
    
    if not filtered_obs:
        return None
    
    # Sort by recency (highest index first)
    filtered_obs.sort(key=lambda x: x['index'], reverse=True)
    
    # Return the most recent valid order block
    return filtered_obs[0]
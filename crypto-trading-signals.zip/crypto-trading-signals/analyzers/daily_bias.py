import numpy as np
import pandas as pd

def analyze_daily_bias(daily_candles, current_idx=None):
    """
    Analyzes daily bias based on candle closures and previous day high/low patterns.
    
    Args:
        daily_candles: DataFrame with daily OHLC data
        current_idx: Index of the current day, defaults to last candle
    
    Returns:
        Dictionary with bias information and targets
    """
    if daily_candles is None or len(daily_candles) < 2:
        return {'bias': 'neutral', 'target': None, 'reason': 'Insufficient data'}
    
    if current_idx is None:
        current_idx = len(daily_candles) - 1
    
    if current_idx < 1 or current_idx >= len(daily_candles):
        return {'bias': 'neutral', 'target': None, 'reason': 'Invalid index'}
    
    prev_day_idx = current_idx - 1
    prev_day = daily_candles.iloc[prev_day_idx]
    current_day = daily_candles.iloc[current_idx]
    
    # Check various patterns
    if current_day['close'] > prev_day['high']:
        return {
            'bias': 'bullish',
            'target': current_day['high'],
            'reason': 'Close above previous day high (bullish continuation)'
        }
    
    elif current_day['close'] < prev_day['low']:
        return {
            'bias': 'bearish',
            'target': current_day['low'],
            'reason': 'Close below previous day low (bearish continuation)'
        }
    
    elif current_day['high'] > prev_day['high'] and current_day['close'] < prev_day['high']:
        return {
            'bias': 'bearish',
            'target': prev_day['low'],
            'reason': 'Wick above previous day high, close below (bearish reversal)'
        }
    
    elif current_day['low'] < prev_day['low'] and current_day['close'] > prev_day['low']:
        return {
            'bias': 'bullish',
            'target': prev_day['high'],
            'reason': 'Wick below previous day low, close above (bullish reversal)'
        }
    
    return {'bias': 'neutral', 'target': None, 'reason': 'No clear pattern'}
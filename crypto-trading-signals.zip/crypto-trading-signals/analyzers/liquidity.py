import numpy as np
import pandas as pd
import config

def detect_liquidity_sweeps(candles, lookback=config.LIQUIDITY_LOOKBACK, 
                           threshold_pips=config.LIQUIDITY_THRESHOLD_PIPS):
    """
    Detects when price sweeps significant highs or lows.
    
    Args:
        candles: DataFrame with OHLC data
        lookback: Number of candles to look back for significant levels
        threshold_pips: Minimum number of pips to consider a level significant
    
    Returns:
        Dictionary of detected sweeps with timestamps
    """
    if candles is None or len(candles) < lookback + 5:
        return {'buy_side': [], 'sell_side': []}
    
    sweeps = {'buy_side': [], 'sell_side': []}
    
    # Find significant highs and lows
    for i in range(lookback, len(candles)-5):
        # Check if current candle is a significant high
        if all(candles['high'].iloc[i] > candles['high'].iloc[i-j] for j in range(1, 5)):
            significant_high = candles['high'].iloc[i]
            
            # Look forward to see if this high gets swept
            for j in range(i+1, min(i+20, len(candles))):
                if candles['high'].iloc[j] > significant_high + threshold_pips * 0.0001 * significant_high:
                    sweeps['buy_side'].append({
                        'sweep_idx': j,
                        'level_idx': i,
                        'level': significant_high,
                        'timestamp': candles.index[j]
                    })
                    break
        
        # Check if current candle is a significant low
        if all(candles['low'].iloc[i] < candles['low'].iloc[i-j] for j in range(1, 5)):
            significant_low = candles['low'].iloc[i]
            
            # Look forward to see if this low gets swept
            for j in range(i+1, min(i+20, len(candles))):
                if candles['low'].iloc[j] < significant_low - threshold_pips * 0.0001 * significant_low:
                    sweeps['sell_side'].append({
                        'sweep_idx': j,
                        'level_idx': i,
                        'level': significant_low,
                        'timestamp': candles.index[j]
                    })
                    break
    
    return sweeps

def analyze_range_liquidity(candles, window=100):
    """
    Identifies internal and external range liquidity points.
    
    Args:
        candles: DataFrame with OHLC data
        window: Range window size
    
    Returns:
        Dictionary with IRL and ERL points
    """
    if candles is None or len(candles) < window + 10:
        return {
            'internal': {'highs': [], 'lows': []},
            'external': {'highs': [], 'lows': []}
        }
    
    # Define current range
    current_high = candles['high'].iloc[-window:].max()
    current_low = candles['low'].iloc[-window:].min()
    range_mid = (current_high + current_low) / 2
    
    liquidity = {
        'internal': {'highs': [], 'lows': []},
        'external': {'highs': [], 'lows': []}
    }
    
    # Find significant swing points
    for i in range(5, len(candles)-5):
        # Check for swing high
        if all(candles['high'].iloc[i] > candles['high'].iloc[i-j] for j in range(1, 5)) and \
           all(candles['high'].iloc[i] > candles['high'].iloc[i+j] for j in range(1, 5)):
            level = candles['high'].iloc[i]
            
            if current_low <= level <= current_high:
                liquidity['internal']['highs'].append({
                    'idx': i,
                    'level': level,
                    'timestamp': candles.index[i],
                    'premium_discount': 'premium' if level > range_mid else 'discount'
                })
            elif level > current_high:
                liquidity['external']['highs'].append({
                    'idx': i,
                    'level': level,
                    'timestamp': candles.index[i]
                })
        
        # Check for swing low
        if all(candles['low'].iloc[i] < candles['low'].iloc[i-j] for j in range(1, 5)) and \
           all(candles['low'].iloc[i] < candles['low'].iloc[i+j] for j in range(1, 5)):
            level = candles['low'].iloc[i]
            
            if current_low <= level <= current_high:
                liquidity['internal']['lows'].append({
                    'idx': i,
                    'level': level,
                    'timestamp': candles.index[i],
                    'premium_discount': 'premium' if level > range_mid else 'discount'
                })
            elif level < current_low:
                liquidity['external']['lows'].append({
                    'idx': i,
                    'level': level,
                    'timestamp': candles.index[i]
                })
    
    return liquidity
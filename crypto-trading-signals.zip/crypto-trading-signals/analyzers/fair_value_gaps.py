import numpy as np
import pandas as pd
import config

def detect_fair_value_gaps(candles, threshold_multiplier=config.FVG_THRESHOLD_MULTIPLIER):
    """
    Detects fair value gaps in candlestick data.
    
    A fair value gap occurs when a candle's low is higher than the previous candle's high (bullish FVG)
    or when a candle's high is lower than the previous candle's low (bearish FVG).
    
    Args:
        candles: DataFrame with OHLC data
        threshold_multiplier: Minimum size of gap as multiple of average candle size
    
    Returns:
        List of detected FVGs with their properties
    """
    if candles is None or len(candles) < 3:
        return []
    
    fvgs = []
    avg_candle_size = (candles['high'] - candles['low']).rolling(20).mean()
    
    for i in range(1, len(candles)-1):
        # Check for bullish FVG
        if candles['low'].iloc[i+1] > candles['high'].iloc[i-1]:
            gap_size = candles['low'].iloc[i+1] - candles['high'].iloc[i-1]
            if gap_size > avg_candle_size.iloc[i] * threshold_multiplier:
                fvgs.append({
                    'type': 'bullish',
                    'start_idx': i-1,
                    'end_idx': i+1,
                    'top': candles['low'].iloc[i+1],
                    'bottom': candles['high'].iloc[i-1],
                    'size': gap_size,
                    'timestamp': candles.index[i],
                    'status': 'active'
                })
        
        # Check for bearish FVG
        if candles['high'].iloc[i+1] < candles['low'].iloc[i-1]:
            gap_size = candles['low'].iloc[i-1] - candles['high'].iloc[i+1]
            if gap_size > avg_candle_size.iloc[i] * threshold_multiplier:
                fvgs.append({
                    'type': 'bearish',
                    'start_idx': i-1,
                    'end_idx': i+1,
                    'top': candles['low'].iloc[i-1],
                    'bottom': candles['high'].iloc[i+1],
                    'size': gap_size,
                    'timestamp': candles.index[i],
                    'status': 'active'
                })
    
    return fvgs
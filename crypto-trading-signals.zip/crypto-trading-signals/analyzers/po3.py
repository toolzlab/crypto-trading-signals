import numpy as np
import pandas as pd

def detect_po3_pattern(candles, current_idx=None):
    """
    Detects Power of Three (PO3) pattern in candlestick data.
    PO3 represents the accumulation, manipulation, and distribution phases.
    
    Args:
        candles: DataFrame with OHLC data
        current_idx: Index of current candle (defaults to last candle)
        
    Returns:
        Dictionary with PO3 pattern information if detected
    """
    if candles is None or len(candles) < 5:
        return None
    
    if current_idx is None:
        current_idx = len(candles) - 1
    
    # Need at least 5 candles before current_idx
    if current_idx < 5:
        return None
    
    # Check for bullish PO3 (open-low-high-close)
    # Price opens, manipulates lower, distributes higher, and closes higher
    bullish_po3 = False
    if (candles['low'].iloc[current_idx] < candles['open'].iloc[current_idx] and
        candles['high'].iloc[current_idx] > candles['open'].iloc[current_idx] and
        candles['close'].iloc[current_idx] > candles['open'].iloc[current_idx]):
        
        # Check if we have manipulation to the downside first
        manipulation_down = False
        for i in range(1, 4):  # Check first few candles after open
            if candles['low'].iloc[current_idx-i] < candles['low'].iloc[current_idx]:
                manipulation_down = True
                break
        
        if manipulation_down:
            bullish_po3 = True
    
    # Check for bearish PO3 (open-high-low-close)
    # Price opens, manipulates higher, distributes lower, and closes lower
    bearish_po3 = False
    if (candles['high'].iloc[current_idx] > candles['open'].iloc[current_idx] and
        candles['low'].iloc[current_idx] < candles['open'].iloc[current_idx] and
        candles['close'].iloc[current_idx] < candles['open'].iloc[current_idx]):
        
        # Check if we have manipulation to the upside first
        manipulation_up = False
        for i in range(1, 4):  # Check first few candles after open
            if candles['high'].iloc[current_idx-i] > candles['high'].iloc[current_idx]:
                manipulation_up = True
                break
        
        if manipulation_up:
            bearish_po3 = True
    
    # Return pattern information
    if bullish_po3:
        return {
            'pattern': 'po3',
            'type': 'bullish',
            'open': candles['open'].iloc[current_idx],
            'manipulation': candles['low'].iloc[current_idx],
            'distribution': candles['high'].iloc[current_idx],
            'close': candles['close'].iloc[current_idx],
            'index': current_idx,
            'timestamp': candles.index[current_idx]
        }
    elif bearish_po3:
        return {
            'pattern': 'po3',
            'type': 'bearish',
            'open': candles['open'].iloc[current_idx],
            'manipulation': candles['high'].iloc[current_idx],
            'distribution': candles['low'].iloc[current_idx],
            'close': candles['close'].iloc[current_idx],
            'index': current_idx,
            'timestamp': candles.index[current_idx]
        }
    
    return None

def analyze_4h_po3(candles, lookback=5):
    """
    Specifically analyze 4-hour candles for PO3 patterns as per Big Char Trades method.
    
    Args:
        candles: DataFrame with 4-hour OHLC data
        lookback: Number of candles to analyze
        
    Returns:
        Dictionary with PO3 analysis
    """
    if candles is None or len(candles) < lookback:
        return None
    
    results = []
    for i in range(len(candles) - lookback, len(candles)):
        po3 = detect_po3_pattern(candles, i)
        if po3:
            results.append(po3)
    
    # If any PO3 patterns were found, return the most recent one
    if results:
        return results[-1]
    
    return None

def is_10am_po3(candle, timezone='UTC'):
    """
    Check if a candle is a 10am PO3 candle as referenced in Big Char Trades.
    
    Args:
        candle: Candle data from a DataFrame
        timezone: Timezone for the check
        
    Returns:
        Boolean indicating if it's a 10am PO3 candle
    """
    # Convert timestamp to datetime with timezone
    timestamp = pd.to_datetime(candle.name)
    
    # Check if it's a 4-hour candle starting at 10am ET (14:00 UTC)
    if timestamp.hour == 14 and timestamp.minute == 0:
        # Check if it has the PO3 pattern
        is_bullish_po3 = (candle['low'] < candle['open'] and 
                          candle['high'] > candle['open'] and 
                          candle['close'] > candle['open'])
        
        is_bearish_po3 = (candle['high'] > candle['open'] and 
                          candle['low'] < candle['open'] and 
                          candle['close'] < candle['open'])
        
        return is_bullish_po3 or is_bearish_po3
    
    return False
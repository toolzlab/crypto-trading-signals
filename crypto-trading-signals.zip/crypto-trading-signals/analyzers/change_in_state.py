import numpy as np
import pandas as pd

def detect_change_in_state(candles, recent_swing_idx, direction='bullish'):
    """
    Detects change in state of delivery.
    
    For bullish change: Candle closure above series of down closed candles that swept lows
    For bearish change: Candle closure below series of up closed candles that swept highs
    
    Args:
        candles: DataFrame with OHLC data
        recent_swing_idx: Index of recent high/low that was swept
        direction: 'bullish' or 'bearish'
    
    Returns:
        Dictionary with change in state information if found, else None
    """
    if candles is None or recent_swing_idx >= len(candles) - 2:
        return None
    
    if direction == 'bullish':
        # Find series of down closed candles that swept the low
        down_candles = []
        for i in range(recent_swing_idx, min(recent_swing_idx + 15, len(candles))):
            if candles['close'].iloc[i] < candles['open'].iloc[i]:  # Down closed candle
                down_candles.append(i)
            elif len(down_candles) > 0:  # First up-closed candle after series
                if candles['low'].iloc[down_candles[0]:i+1].min() < candles['low'].iloc[recent_swing_idx]:
                    # Series swept the low, check for closure above
                    if candles['close'].iloc[i] > max([candles['close'].iloc[j] for j in down_candles]):
                        return {
                            'direction': 'bullish',
                            'sweep_idx': recent_swing_idx,
                            'down_series': down_candles,
                            'cis_idx': i,
                            'price': candles['close'].iloc[i],
                            'timestamp': candles.index[i]
                        }
                break
    
    elif direction == 'bearish':
        # Find series of up closed candles that swept the high
        up_candles = []
        for i in range(recent_swing_idx, min(recent_swing_idx + 15, len(candles))):
            if candles['close'].iloc[i] > candles['open'].iloc[i]:  # Up closed candle
                up_candles.append(i)
            elif len(up_candles) > 0:  # First down-closed candle after series
                if candles['high'].iloc[up_candles[0]:i+1].max() > candles['high'].iloc[recent_swing_idx]:
                    # Series swept the high, check for closure below
                    if candles['close'].iloc[i] < min([candles['close'].iloc[j] for j in up_candles]):
                        return {
                            'direction': 'bearish',
                            'sweep_idx': recent_swing_idx,
                            'up_series': up_candles,
                            'cis_idx': i,
                            'price': candles['close'].iloc[i],
                            'timestamp': candles.index[i]
                        }
                break
    
    return None
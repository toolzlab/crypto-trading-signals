import pandas as pd
from binance.client import Client
from datetime import datetime, timedelta
import config

class BinanceClient:
    def __init__(self, api_key=config.API_KEY, api_secret=config.API_SECRET):
        self.client = Client(api_key, api_secret)
        self.timeframes = {
            '4h': Client.KLINE_INTERVAL_4HOUR,
            '1h': Client.KLINE_INTERVAL_1HOUR,
            '15m': Client.KLINE_INTERVAL_15MINUTE,
            '5m': Client.KLINE_INTERVAL_5MINUTE,
            '1m': Client.KLINE_INTERVAL_1MINUTE,
            '1d': Client.KLINE_INTERVAL_1DAY,
            '1w': Client.KLINE_INTERVAL_1WEEK
        }
        
    def get_candles(self, symbol, timeframe, limit=500):
        """
        Get candlestick data from Binance
        
        Args:
            symbol: Trading pair symbol
            timeframe: Candle timeframe
            limit: Number of candles to retrieve
            
        Returns:
            DataFrame with OHLC data
        """
        try:
            klines = self.client.get_klines(
                symbol=symbol,
                interval=self.timeframes[timeframe],
                limit=limit
            )
            
            df = pd.DataFrame(klines, columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_asset_volume', 'number_of_trades',
                'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore'
            ])
            
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df.set_index('timestamp', inplace=True)
            
            # Convert string columns to numeric
            for col in ['open', 'high', 'low', 'close', 'volume']:
                df[col] = pd.to_numeric(df[col])
            
            return df
        
        except Exception as e:
            print(f"Error fetching candles for {symbol} on {timeframe}: {e}")
            return None
    
    def get_all_timeframes(self, symbol):
        """
        Get data for all relevant timeframes for a given symbol
        
        Args:
            symbol: Trading pair symbol
            
        Returns:
            Dictionary with DataFrames for each timeframe
        """
        candles = {}
        for tf in self.timeframes:
            candles[tf] = self.get_candles(symbol, tf)
        
        return candles
    
    def get_current_price(self, symbol):
        """Get current price for a symbol"""
        try:
            ticker = self.client.get_symbol_ticker(symbol=symbol)
            return float(ticker['price'])
        except Exception as e:
            print(f"Error getting current price for {symbol}: {e}")
            return None
from datetime import datetime, timedelta
import pandas as pd
import config

def get_aligned_timeframe(source_timeframe):
    """
    Get the correctly aligned timeframe based on source timeframe
    
    Args:
        source_timeframe: Higher timeframe (e.g., '4h', '1h', '15m')
        
    Returns:
        Aligned lower timeframe
    """
    return config.TIMEFRAME_ALIGNMENTS.get(source_timeframe)

def time_to_next_candle(timeframe):
    """
    Calculate time remaining until the next candle opens
    
    Args:
        timeframe: Timeframe string (e.g., '1h', '15m')
        
    Returns:
        Seconds until next candle opens
    """
    now = datetime.now()
    
    if timeframe == '1m':
        next_candle = now.replace(second=0, microsecond=0) + timedelta(minutes=1)
    elif timeframe == '5m':
        minutes_to_add = 5 - (now.minute % 5)
        next_candle = now.replace(second=0, microsecond=0) + timedelta(minutes=minutes_to_add)
    elif timeframe == '15m':
        minutes_to_add = 15 - (now.minute % 15)
        next_candle = now.replace(second=0, microsecond=0) + timedelta(minutes=minutes_to_add)
    elif timeframe == '1h':
        next_candle = now.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
    elif timeframe == '4h':
        hours_to_add = 4 - (now.hour % 4)
        next_candle = now.replace(minute=0, second=0, microsecond=0) + timedelta(hours=hours_to_add)
    elif timeframe == '1d':
        next_candle = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        return None
    
    seconds_remaining = (next_candle - now).total_seconds()
    return max(0, seconds_remaining)

def timeframe_to_seconds(timeframe):
    """
    Convert timeframe string to seconds
    
    Args:
        timeframe: Timeframe string (e.g., '1h', '15m')
        
    Returns:
        Seconds in the timeframe
    """
    if timeframe == '1m':
        return 60
    elif timeframe == '5m':
        return 5 * 60
    elif timeframe == '15m':
        return 15 * 60
    elif timeframe == '1h':
        return 60 * 60
    elif timeframe == '4h':
        return 4 * 60 * 60
    elif timeframe == '1d':
        return 24 * 60 * 60
    elif timeframe == '1w':
        return 7 * 24 * 60 * 60
    return None

def find_timeframe_overlaps(candles_dict):
    """
    Find candles across timeframes that overlap with the latest candle
    
    Args:
        candles_dict: Dictionary containing dataframes of different timeframes
        
    Returns:
        Dictionary with the overlapping candles across timeframes
    """
    if not candles_dict or '1m' not in candles_dict:
        return {}
    
    overlaps = {}
    latest_time = candles_dict['1m'].index[-1]
    
    for tf, df in candles_dict.items():
        if df is None or df.empty:
            continue
            
        # Find the candle that contains the latest minute
        for i in range(len(df)-1, -1, -1):
            candle_time = df.index[i]
            candle_end = candle_time + pd.Timedelta(timeframe_to_seconds(tf), unit='s')
            
            if candle_time <= latest_time < candle_end:
                overlaps[tf] = df.iloc[i]
                break
    
    return overlaps

def is_new_york_trading_hours():
    """
    Check if current time is within New York trading hours (9:30 AM - 4:00 PM ET)
    
    Returns:
        Boolean indicating if market is open
    """
    # Convert current UTC time to US Eastern Time
    now_utc = datetime.now()
    est_offset = -4 if datetime.now().timetuple().tm_isdst else -5
    now_est = now_utc + timedelta(hours=est_offset)
    
    # Check if it's a weekday
    if now_est.weekday() >= 5:  # Saturday or Sunday
        return False
        
    # Check if it's within trading hours (9:30 AM - 4:00 PM ET)
    market_open = now_est.replace(hour=9, minute=30, second=0, microsecond=0)
    market_close = now_est.replace(hour=16, minute=0, second=0, microsecond=0)
    
    return market_open <= now_est <= market_close

def get_candle_info_string(candle):
    """
    Create a readable string with candle information
    
    Args:
        candle: Series containing OHLC data
        
    Returns:
        Formatted string with candle info
    """
    if candle is None:
        return "No candle data"
        
    is_bullish = candle['close'] > candle['open']
    
    return (
        f"{'🟢' if is_bullish else '🔴'} "
        f"O: {candle['open']:.2f} "
        f"H: {candle['high']:.2f} "
        f"L: {candle['low']:.2f} "
        f"C: {candle['close']:.2f} "
        f"V: {candle['volume']:.2f}"
    )
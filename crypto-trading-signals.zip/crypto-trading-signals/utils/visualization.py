import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
import numpy as np
from matplotlib.patches import Rectangle
import mplfinance as mpf
import io
import base64

def plot_candles_with_signals(candles, signals=None, fair_value_gaps=None, liquidity_levels=None, change_in_state=None):
    """
    Plot candlestick chart with trading signals
    
    Args:
        candles: DataFrame with OHLC data
        signals: List of trading signals
        fair_value_gaps: List of fair value gaps
        liquidity_levels: Dictionary of liquidity levels
        change_in_state: Dictionary of change in state points
        
    Returns:
        Figure and base64 encoded image
    """
    # Create figure and axis
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # Convert candles to format suitable for mplfinance
    df = candles.copy()
    df.index = pd.to_datetime(df.index)
    
    # Plot candlestick chart
    mpf.plot(df, type='candle', style='yahoo', ax=ax, volume=False, show_nontrading=False)
    
    # Plot fair value gaps if provided
    if fair_value_gaps:
        for fvg in fair_value_gaps:
            start_idx = fvg['start_idx']
            end_idx = fvg['end_idx']
            color = 'lightgreen' if fvg['type'] == 'bullish' else 'lightcoral'
            alpha = 0.3
            
            # Convert indices to dates
            start_date = candles.index[start_idx]
            end_date = candles.index[end_idx]
            
            # Create rectangle
            rect = Rectangle((mdates.date2num(start_date), fvg['bottom']),
                           mdates.date2num(end_date) - mdates.date2num(start_date),
                           fvg['top'] - fvg['bottom'],
                           facecolor=color, alpha=alpha)
            ax.add_patch(rect)
    
    # Plot liquidity levels if provided
    if liquidity_levels:
        for level_type, levels in liquidity_levels.get('external', {}).items():
            for level in levels:
                color = 'red' if level_type == 'highs' else 'green'
                ax.axhline(y=level['level'], color=color, linestyle='--', alpha=0.7, 
                           label=f"External {level_type}")
        
        for level_type, levels in liquidity_levels.get('internal', {}).items():
            for level in levels:
                color = 'darkred' if level_type == 'highs' else 'darkgreen'
                ax.axhline(y=level['level'], color=color, linestyle='-', alpha=0.5, 
                           label=f"Internal {level_type}")
    
    # Plot change in state points if provided
    if change_in_state:
        if change_in_state.get('direction') == 'bullish':
            direction_marker = '^'
            color = 'green'
        else:
            direction_marker = 'v'
            color = 'red'
            
        cis_idx = change_in_state.get('cis_idx')
        if cis_idx is not None and cis_idx < len(candles):
            cis_date = candles.index[cis_idx]
            cis_price = change_in_state.get('price')
            ax.plot(cis_date, cis_price, direction_marker, color=color, 
                    markersize=10, label='Change in State')
    
    # Plot signals if provided
    if signals:
        for signal in signals:
            signal_date = pd.to_datetime(signal['generated_at'])
            if signal_date not in candles.index:
                continue
                
            marker = '^' if signal['type'] == 'long' else 'v'
            color = 'g' if signal['type'] == 'long' else 'r'
            
            # Plot entry
            ax.plot(signal_date, signal['entry'], marker, color=color, 
                    markersize=10, label=f"{signal['type'].capitalize()} Entry")
            
            # Plot stop
            ax.plot(signal_date, signal['stop'], 's', color='red', 
                    markersize=8, label=f"Stop")
            
            # Plot target
            ax.plot(signal_date, signal['target'], 'D', color='blue', 
                    markersize=8, label=f"Target")
    
    # Format the axis
    ax.set_title("Price Chart with Trading Signals", fontsize=15)
    ax.set_ylabel("Price", fontsize=12)
    ax.grid(True, alpha=0.3)
    
    # Remove duplicate labels
    handles, labels = plt.gca().get_legend_handles_labels()
    by_label = dict(zip(labels, handles))
    plt.legend(by_label.values(), by_label.keys(), loc='upper left')
    
    # Adjust layout
    plt.tight_layout()
    
    # Convert plot to base64 for web display
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    
    graphic = base64.b64encode(image_png).decode('utf-8')
    
    return fig, graphic

def create_dashboard_html(signals_data, chart_images=None):
    """
    Create an HTML dashboard to visualize signals
    
    Args:
        signals_data: Dictionary of trading signals
        chart_images: Dictionary of base64 encoded chart images
        
    Returns:
        HTML string for the dashboard
    """
    html = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Crypto Trading Signals Dashboard</title>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f5f5f5;
            }
            .container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 20px;
            }
            .header {
                background-color: #2c3e50;
                color: white;
                padding: 20px;
                text-align: center;
                border-radius: 5px 5px 0 0;
            }
            .signal-card {
                background-color: white;
                border-radius: 5px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                margin-bottom: 20px;
                overflow: hidden;
            }
            .signal-header {
                padding: 15px;
                border-bottom: 1px solid #eee;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            .signal-header h2 {
                margin: 0;
                font-size: 1.5em;
            }
            .signal-body {
                padding: 15px;
            }
            .signal-details {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
                gap: 15px;
                margin-bottom: 15px;
            }
            .detail-item {
                padding: 10px;
                background-color: #f8f9fa;
                border-radius: 4px;
            }
            .detail-label {
                font-weight: bold;
                color: #555;
                margin-bottom: 5px;
            }
            .detail-value {
                font-size: 1.2em;
            }
            .reasons {
                background-color: #f8f9fa;
                padding: 15px;
                border-radius: 4px;
            }
            .reasons h3 {
                margin-top: 0;
            }
            .reasons ul {
                margin: 0;
                padding-left: 20px;
            }
            .chart-container {
                margin-top: 15px;
            }
            .long {
                border-left: 5px solid #4caf50;
            }
            .short {
                border-left: 5px solid #f44336;
            }
            .confidence {
                display: inline-block;
                padding: 5px 10px;
                border-radius: 15px;
                font-weight: bold;
                color: white;
            }
            .high {
                background-color: #4caf50;
            }
            .medium {
                background-color: #ff9800;
            }
            .low {
                background-color: #f44336;
            }
            .timestamp {
                color: #777;
                font-size: 0.9em;
            }
            .no-signals {
                background-color: white;
                padding: 30px;
                text-align: center;
                border-radius: 5px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Crypto Trading Signals Dashboard</h1>
                <p>Generated at: """ + pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S') + """</p>
            </div>
    """
    
    if not signals_data or all(len(signals) == 0 for signals in signals_data.values()):
        html += """
            <div class="no-signals">
                <h2>No trading signals detected</h2>
                <p>The system didn't find any valid trade setups at this time.</p>
            </div>
        """
    else:
        for symbol, signals in signals_data.items():
            for i, signal in enumerate(signals):
                confidence_class = "high" if signal['confidence'] >= 80 else "medium" if signal['confidence'] >= 60 else "low"
                signal_class = signal['type']
                
                html += f"""
                <div class="signal-card {signal_class}">
                    <div class="signal-header">
                        <h2>{signal['symbol']} - {signal['type'].upper()} Signal</h2>
                        <span class="confidence {confidence_class}">{signal['confidence']}% Confidence</span>
                    </div>
                    <div class="signal-body">
                        <div class="signal-details">
                            <div class="detail-item">
                                <div class="detail-label">Entry Price</div>
                                <div class="detail-value">${signal['entry']:.4f}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Stop Loss</div>
                                <div class="detail-value">${signal['stop']:.4f}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Target Price</div>
                                <div class="detail-value">${signal['target']:.4f}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Current Price</div>
                                <div class="detail-value">${signal['current_price']:.4f}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Position Size</div>
                                <div class="detail-value">{signal['position_size']['units']:.4f} units</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Position Value</div>
                                <div class="detail-value">${signal['position_size']['position_value']:.2f}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Risk</div>
                                <div class="detail-value">${signal['position_size']['max_loss']:.2f}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Timeframe</div>
                                <div class="detail-value">{signal['timeframe_combo']}</div>
                            </div>
                        </div>
                        
                        <div class="reasons">
                            <h3>Signal Reasoning</h3>
                            <ul>
                """
                
                for reason in signal['reasons']:
                    html += f"<li>{reason}</li>"
                
                html += """
                            </ul>
                        </div>
                """
                
                # Add chart if available
                chart_key = f"{symbol}_{i}"
                if chart_images and chart_key in chart_images:
                    html += f"""
                        <div class="chart-container">
                            <img src="data:image/png;base64,{chart_images[chart_key]}" alt="Chart" style="width: 100%;">
                        </div>
                    """
                
                html += f"""
                        <p class="timestamp">Generated: {signal['generated_at']}</p>
                    </div>
                </div>
                """
    
    html += """
        </div>
    </body>
    </html>
    """
    
    return html

def save_dashboard_html(html_content, filename="dashboard.html"):
    """
    Save the dashboard HTML to a file
    
    Args:
        html_content: HTML string
        filename: Output filename
    """
    with open(filename, "w") as f:
        f.write(html_content)
    
    print(f"Dashboard saved to {filename}")

def plot_multiple_timeframes(candles_dict, symbol, signals=None):
    """
    Create a multi-timeframe analysis chart
    
    Args:
        candles_dict: Dictionary with candles data for different timeframes
        symbol: Trading pair symbol
        signals: List of trading signals
        
    Returns:
        Figure and base64 encoded image
    """
    # Define the timeframes to plot
    timeframes = ['1d', '4h', '1h', '15m']
    available_tfs = [tf for tf in timeframes if tf in candles_dict and candles_dict[tf] is not None]
    
    if not available_tfs:
        return None, None
    
    # Create subplots
    fig, axes = plt.subplots(len(available_tfs), 1, figsize=(12, 4*len(available_tfs)), gridspec_kw={'hspace': 0.3})
    if len(available_tfs) == 1:
        axes = [axes]
    
    # Plot each timeframe
    for i, tf in enumerate(available_tfs):
        df = candles_dict[tf].copy().tail(100)  # Get last 100 candles for better visibility
        df.index = pd.to_datetime(df.index)
        
        # Plot candlesticks
        mpf.plot(df, type='candle', style='yahoo', ax=axes[i], volume=False, show_nontrading=False)
        
        # Set title
        axes[i].set_title(f"{symbol} - {tf} Timeframe", fontsize=12)
        axes[i].set_ylabel("Price", fontsize=10)
        axes[i].grid(True, alpha=0.3)
        
        # Plot signals for this timeframe if available
        if signals:
            relevant_signals = [s for s in signals if tf in s['timeframe_combo']]
            for signal in relevant_signals:
                marker = '^' if signal['type'] == 'long' else 'v'
                color = 'g' if signal['type'] == 'long' else 'r'
                
                # Find closest candle to signal time
                signal_time = pd.to_datetime(signal['generated_at'])
                closest_candle = df.index[df.index <= signal_time][-1] if any(df.index <= signal_time) else None
                
                if closest_candle:
                    # Plot entry, stop and target
                    axes[i].plot(closest_candle, signal['entry'], marker, color=color, markersize=10)
                    axes[i].plot(closest_candle, signal['stop'], 's', color='red', markersize=8)
                    axes[i].plot(closest_candle, signal['target'], 'D', color='blue', markersize=8)
    
    # Add legend to the last subplot
    axes[-1].legend(['Entry', 'Stop', 'Target'], loc='upper left')
    
    # Adjust layout
    plt.tight_layout()
    
    # Convert plot to base64 for web display
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    
    graphic = base64.b64encode(image_png).decode('utf-8')
    
    return fig, graphic
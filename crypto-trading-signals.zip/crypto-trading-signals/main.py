import time
import json
from datetime import datetime
import config
from binance_client import BinanceClient
from signal_generator import SignalGenerator

# Add this custom JSON encoder to handle datetime objects
class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super(DateTimeEncoder, self).default(obj)

def save_signals_to_file(signals, filename="signals.json"):
    """Save signals to a JSON file with timestamp"""
    with open(filename, 'w') as f:
        json.dump({
            'generated_at': datetime.now().isoformat(),
            'signals': signals
        }, f, indent=2, cls=DateTimeEncoder)  # Use the custom encoder

def format_signal_for_display(signal):
    """Format a signal nicely for console display"""
    output = [
        f"{'='*60}",
        f"📊 SIGNAL: {signal['type'].upper()} {signal['symbol']} ({signal['confidence']}% confidence)",
        f"{'='*60}",
        f"⏱️ Timeframe: {signal['timeframe_combo']}",
        f"📈 Entry: {signal['entry']:.4f} (Current: {signal['current_price']:.4f})",
        f"🛑 Stop: {signal['stop']:.4f}",
        f"🎯 Target: {signal['target']:.4f}",
        f"💰 Position: {signal['position_size']['units']:.4f} units (${signal['position_size']['position_value']:.2f})",
        f"⚠️ Risk: ${signal['position_size']['max_loss']:.2f} ({signal['position_size']['risk_percentage']:.2f}%)",
        f"📝 Reasons:"
    ]
    
    for reason in signal['reasons']:
        output.append(f"  • {reason}")
    
    # Convert generated_at to string if it's a datetime object
    generated_at = signal['generated_at']
    if isinstance(generated_at, datetime):
        generated_at = generated_at.isoformat()
    
    output.append(f"\nGenerated: {generated_at}")
    
    return "\n".join(output)

def run_scanner(interval_minutes=5):  # Changed to 5 minutes
    """
    Run the signal scanner at specified intervals
    
    Args:
        interval_minutes: Interval between scans in minutes
    """
    print(f"Starting Big Char Trades Crypto Scanner")
    print(f"Watching pairs: {', '.join(config.PRIMARY_PAIRS)}")
    print(f"Scan interval: {interval_minutes} minutes")
    print(f"{'='*60}")
    
    client = BinanceClient()
    generator = SignalGenerator(client)
    
    while True:
        try:
            print(f"\n[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Running scan...")
            
            # Generate signals for all pairs
            all_signals = generator.scan_all_pairs()
            
            # Count signals
            total_signals = sum(len(signals) for signals in all_signals.values())
            
            # Print results
            if total_signals > 0:
                print(f"Found {total_signals} potential signals:")
                
                # Display high confidence signals
                high_conf_signals = []
                for symbol, signals in all_signals.items():
                    for signal in signals:
                        if signal['confidence'] >= 80:
                            high_conf_signals.append(signal)
                
                if high_conf_signals:
                    print(f"\n🔥 HIGH CONFIDENCE SIGNALS ({len(high_conf_signals)}):")
                    for signal in high_conf_signals:
                        print(format_signal_for_display(signal))
                
                # Save all signals to file
                save_signals_to_file(all_signals)
                print(f"\nAll signals saved to signals.json")
            else:
                print("No signals found in this scan.")
            
            # Wait for next interval
            print(f"\nNext scan in {interval_minutes} minutes...")
            time.sleep(interval_minutes * 60)
            
        except KeyboardInterrupt:
            print("\nScanner stopped by user.")
            break
        except Exception as e:
            print(f"\nError in scanner: {e}")
            # Wait a bit and try again
            time.sleep(60)

if __name__ == "__main__":
    run_scanner(5)  # Run every 5 minutes
# Updated signal_generator.py with signal filtering
from datetime import datetime
import config
from analyzers import daily_bias, fair_value_gaps, liquidity, change_in_state, smt, order_blocks, po3
from risk_manager import calculate_position_size

class SignalGenerator:
    def __init__(self, binance_client):
        self.client = binance_client
        
    def generate_signals(self, symbol, max_signals_per_pair=1):
        """
        Generate trading signals for a specific symbol by analyzing multiple timeframes
        
        Args:
            symbol: Trading pair symbol
            max_signals_per_pair: Maximum number of signals to return per pair
            
        Returns:
            List of trade signals with entry, stop and target levels
        """
        signals = []
        
        # Get data for all timeframes
        candles = self.client.get_all_timeframes(symbol)
        
        # Get correlated asset data
        correlated_symbol = config.CORRELATED_PAIRS.get(symbol)
        if correlated_symbol:
            correlated_candles = self.client.get_all_timeframes(correlated_symbol)
        else:
            correlated_candles = None
        
        # Step 1: Analyze daily bias
        daily_bias_result = daily_bias.analyze_daily_bias(candles['1d'])
        
        # Loop through all relevant timeframe alignments
        for htf, ltf in config.TIMEFRAME_ALIGNMENTS.items():
            if htf not in candles or ltf not in candles:
                continue
                
            # Step 2: Higher timeframe analysis
            htf_fvgs = fair_value_gaps.detect_fair_value_gaps(candles[htf])
            htf_liquidity = liquidity.analyze_range_liquidity(candles[htf])
            
            # Step 3: Lower timeframe analysis
            ltf_sweeps = liquidity.detect_liquidity_sweeps(candles[ltf])
            
            # Step 4: SMT analysis
            if correlated_candles and htf in correlated_candles and ltf in correlated_candles:
                htf_smt = smt.detect_smt(candles[htf], correlated_candles[htf])
                ltf_smt = smt.detect_smt(candles[ltf], correlated_candles[ltf])
                has_smt = (len(htf_smt['bullish']) > 0 or len(ltf_smt['bullish']) > 0 or 
                           len(htf_smt['bearish']) > 0 or len(ltf_smt['bearish']) > 0)
            else:
                htf_smt = {'bullish': [], 'bearish': []}
                ltf_smt = {'bullish': [], 'bearish': []}
                has_smt = False
            
            # Step 5: Look for bullish setups
            for sweep in ltf_sweeps['sell_side']:
                # Only process bullish signals if daily bias allows
                if daily_bias_result['bias'] in ['bullish', 'neutral']:
                    # Check for bullish change in state after sell-side liquidity sweep
                    cis = change_in_state.detect_change_in_state(
                        candles[ltf], 
                        sweep['level_idx'], 
                        'bullish'
                    )
                    
                    if cis:
                        # Check if we swept into a higher timeframe PDR (FVG)
                        relevant_pdr = None
                        for fvg in htf_fvgs:
                            if fvg['type'] == 'bullish':
                                if fvg['bottom'] <= sweep['level'] <= fvg['top']:
                                    relevant_pdr = {'type': 'fvg', 'details': fvg}
                                    break
                        
                        # If we have valid PDR and change in state
                        if relevant_pdr:
                            # Calculate entry, stop and target
                            entry_price = cis['price']
                            stop_price = sweep['level'] * 0.995  # Protected low with small buffer
                            risk = entry_price - stop_price
                            target_price = entry_price + (risk * 2)  # 2R target
                            
                            # Get current price
                            current_price = self.client.get_current_price(symbol)
                            
                            # If current price is within 1% of entry, consider it a valid signal
                            if current_price and abs(current_price - entry_price) / entry_price <= 0.01:
                                # Calculate position size
                                position_info = calculate_position_size(
                                    config.ACCOUNT_SIZE,
                                    config.RISK_PER_TRADE,
                                    entry_price,
                                    stop_price,
                                    current_price
                                )
                                
                                # Calculate confidence score
                                confidence = 60  # Base confidence
                                if daily_bias_result['bias'] == 'bullish':
                                    confidence += 15
                                elif daily_bias_result['bias'] == 'neutral':
                                    confidence += 5
                                if has_smt:
                                    confidence += 15
                                if relevant_pdr['type'] == 'fvg':
                                    confidence += 10

                                # Add timeframe weight with stronger preference for 4h->15m
                                if htf == '4h' and ltf == '15m':
                                    confidence += 20  # Give a significant boost to 4h->15m
                                elif htf == '4h':
                                    confidence += 10  # Still favor 4h with other timeframes
                                elif htf == '1h' and ltf == '5m':
                                    confidence += 5   # Less boost for 1h->5m
                                
                                # Create signal
                                signal = {
                                    'symbol': symbol,
                                    'type': 'long',
                                    'entry': entry_price,
                                    'stop': stop_price,
                                    'target': target_price,
                                    'current_price': current_price,
                                    'timeframe_combo': f"{htf}->{ltf}",
                                    'position_size': position_info,
                                    'confidence': confidence,
                                    'reasons': [
                                        f"Sell-side liquidity sweep at {sweep['level']}",
                                        f"Bullish change in state on {ltf} timeframe",
                                        f"Trading into bullish {relevant_pdr['type']} on {htf} timeframe"
                                    ],
                                    'generated_at': datetime.now()
                                }
                                
                                if daily_bias_result['bias'] == 'bullish':
                                    signal['reasons'].append(f"Daily bias supports (is {daily_bias_result['bias']})")
                                
                                if has_smt:
                                    signal['reasons'].append("SMT confirms bullish divergence")
                                    
                                signals.append(signal)
            
            # Step 6: Look for bearish setups
            for sweep in ltf_sweeps['buy_side']:
                # Only process bearish signals if daily bias allows
                if daily_bias_result['bias'] in ['bearish', 'neutral']:
                    # Check for bearish change in state after buy-side liquidity sweep
                    cis = change_in_state.detect_change_in_state(
                        candles[ltf], 
                        sweep['level_idx'], 
                        'bearish'
                    )
                    
                    if cis:
                        # Check if we swept into a higher timeframe PDR (FVG)
                        relevant_pdr = None
                        for fvg in htf_fvgs:
                            if fvg['type'] == 'bearish':
                                if fvg['bottom'] <= sweep['level'] <= fvg['top']:
                                    relevant_pdr = {'type': 'fvg', 'details': fvg}
                                    break
                        
                        # If we have valid PDR and change in state
                        if relevant_pdr:
                            # Calculate entry, stop and target
                            entry_price = cis['price']
                            stop_price = sweep['level'] * 1.005  # Protected high with small buffer
                            risk = stop_price - entry_price
                            target_price = entry_price - (risk * 2)  # 2R target
                            
                            # Get current price
                            current_price = self.client.get_current_price(symbol)
                            
                            # If current price is within 1% of entry, consider it a valid signal
                            if current_price and abs(current_price - entry_price) / entry_price <= 0.01:
                                # Calculate position size
                                position_info = calculate_position_size(
                                    config.ACCOUNT_SIZE,
                                    config.RISK_PER_TRADE,
                                    entry_price,
                                    stop_price,
                                    current_price
                                )
                                
                                # Calculate confidence score
                                confidence = 60  # Base confidence
                                if daily_bias_result['bias'] == 'bearish':
                                    confidence += 15
                                elif daily_bias_result['bias'] == 'neutral':
                                    confidence += 5
                                if has_smt:
                                    confidence += 15
                                if relevant_pdr['type'] == 'fvg':
                                    confidence += 10
                                
                                # Add timeframe weight - higher timeframes get higher confidence
                                if htf == '4h':
                                    confidence += 10
                                elif htf == '1h':
                                    confidence += 5
                                
                                # Create signal
                                signal = {
                                    'symbol': symbol,
                                    'type': 'short',
                                    'entry': entry_price,
                                    'stop': stop_price,
                                    'target': target_price,
                                    'current_price': current_price,
                                    'timeframe_combo': f"{htf}->{ltf}",
                                    'position_size': position_info,
                                    'confidence': confidence,
                                    'reasons': [
                                        f"Buy-side liquidity sweep at {sweep['level']}",
                                        f"Bearish change in state on {ltf} timeframe",
                                        f"Trading into bearish {relevant_pdr['type']} on {htf} timeframe"
                                    ],
                                    'generated_at': datetime.now()
                                }
                                
                                if daily_bias_result['bias'] == 'bearish':
                                    signal['reasons'].append(f"Daily bias supports (is {daily_bias_result['bias']})")
                                
                                if has_smt:
                                    signal['reasons'].append("SMT confirms bearish divergence")
                                    
                                signals.append(signal)
        
        # Filter and sort signals based on confidence
        signals.sort(key=lambda x: x['confidence'], reverse=True)
        
        # Apply signal limit per pair
        if max_signals_per_pair > 0 and len(signals) > max_signals_per_pair:
            signals = signals[:max_signals_per_pair]
        
        return signals
    
    def scan_all_pairs(self, max_signals_per_pair=1):
        """
        Scan all trading pairs for potential signals
        
        Args:
            max_signals_per_pair: Maximum number of signals to return per pair
            
        Returns:
            Dictionary with signals for each pair
        """
        all_signals = {}
        
        for symbol in config.PRIMARY_PAIRS:
            try:
                symbol_signals = self.generate_signals(symbol, max_signals_per_pair)
                if symbol_signals:
                    all_signals[symbol] = symbol_signals
            except Exception as e:
                print(f"Error generating signals for {symbol}: {e}")
        
        return all_signals
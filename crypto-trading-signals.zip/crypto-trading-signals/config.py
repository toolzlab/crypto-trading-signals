# Configuration settings for the trading signal system

# API settings
API_KEY = "6eKLeJ09FjzMaJKVVWfjolGFxFWaWks1xLauCzzpTg2gGpEss9jnIlRpH5rBsXwl"
API_SECRET = "R9VpWTOomWDmgZm2tlJOcdkwQr3L4y9X4f99WbPu1L7KmDTpsbqRgIf0GiMEuG1B"

# Configuration settings for the trading signal system

# API settings
API_KEY = "your_binance_api_key"
API_SECRET = "your_binance_api_secret"

# Trading pairs
PRIMARY_PAIRS = [
    "BTCUSDT", "ETHUSDT", "BNBUSDT", "ADAUSDT", "SOLUSDT", 
    "DOTUSDT", "XRPUSDT", "LTCUSDT"  # Added the new pairs
]

# Correlated pairs for SMT analysis
CORRELATED_PAIRS = {
    "BTCUSDT": "ETHUSDT",
    "ETHUSDT": "BTCUSDT",
    "BNBUSDT": "BTCUSDT",
    "ADAUSDT": "ETHUSDT",
    "SOLUSDT": "BTCUSDT",
    "DOTUSDT": "BTCUSDT",  # Added DOT with BTC correlation
    "XRPUSDT": "BTCUSDT",  # Added XRP with BTC correlation
    "LTCUSDT": "BTCUSDT"   # Added LTC with BTC correlation
}

# Timeframe alignments (as per Big Char Trades methodology)
TIMEFRAME_ALIGNMENTS = {
    "4h": "15m",  # 4-Hour PD array aligns with 15-minute change in state
    "1h": "5m",   # 1-Hour PD array aligns with 5-minute change in state
    "15m": "1m"   # 15-minute PD array aligns with 1-minute change in state
}

# Risk management settings
ACCOUNT_SIZE = 50  # Total account size in USD
RISK_PER_TRADE = 20  # Fixed dollar risk per trade
MAX_RISK_PERCENT = 40  # Maximum percentage of account to risk per trade (40% of $50 = $20)
LEVERAGE = 35  # Leverage multiplier

# FVG detection settings
FVG_THRESHOLD_MULTIPLIER = 1.5  # Minimum size of gap as multiple of average candle size

# Liquidity settings
LIQUIDITY_LOOKBACK = 50         # Number of candles to look back for significant levels
LIQUIDITY_THRESHOLD_PIPS = 20   # Minimum number of pips to consider a level significant